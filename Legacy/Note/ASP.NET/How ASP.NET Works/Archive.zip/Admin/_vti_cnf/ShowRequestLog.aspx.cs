vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 11:28:15 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{AAE265D9-3AAD-48C3-A03D-428C1FAF2019}
vti_cacheddtm:TX|14 Oct 2003 11:28:15 -0000
vti_filesize:IR|4131
vti_backlinkinfo:VX|
