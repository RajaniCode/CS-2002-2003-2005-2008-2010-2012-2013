using System;

namespace _3DTools
{
    public enum ViewMode
    {
        Solid,
        Wireframe
    }
}
