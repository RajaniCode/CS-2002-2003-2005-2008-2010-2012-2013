Project Status
==============

Apache log4net is a sub project of the Apache Logging Services project. 
Apache log4net graduated from the Apache Incubator in February 2007.
Web site: http://logging.apache.org/log4net


Documentation
=============

For local documentation, which is correct for this release see:
doc/index.html

For the latest documentation see the log4net web site at:
http://logging.apache.org/log4net
