﻿//Copyright (C) Microsoft Corporation.  All rights reserved.

// Hello1.cs
public class Hello1
{
   public static void Main()
   {
      System.Console.WriteLine("Hello, World!");
   }
}

