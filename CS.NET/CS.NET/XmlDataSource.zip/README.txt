To run these demos, open the folder as a file-system-based website project in Visual Studio 2005.

Don't have Visual Studio 2005? You can download a free "Express" version:
http://msdn.microsoft.com/vstudio/express/vwd/


	Scott Mitchell
	mitchell@4guysfromrolla.com
	Blog: http://ScottOnWriting.NET
	
