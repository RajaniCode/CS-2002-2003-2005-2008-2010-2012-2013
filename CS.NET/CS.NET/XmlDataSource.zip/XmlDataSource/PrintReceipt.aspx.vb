
Partial Class PrintReceipt
    Inherits System.Web.UI.Page

End Class
