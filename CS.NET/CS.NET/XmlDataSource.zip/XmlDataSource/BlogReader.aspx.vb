
Partial Class BlogReader
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'On first page load, populate the DataList
        If Not Page.IsPostBack Then
            BindData()
        End If
    End Sub

    Protected Sub RefreshFeed_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RefreshFeed.Click
        BindData()
    End Sub

    Private Sub BindData()
        'Update the feed's URL
        RSSFeedDataSource.DataFile = FeedUrl.Text
        FeedList.DataBind()
    End Sub

End Class
