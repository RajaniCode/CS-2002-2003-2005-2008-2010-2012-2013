
Partial Class Hierarchy
    Inherits System.Web.UI.Page

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        Dim suppliersAdapter As New NorthwindTableAdapters.SuppliersTableAdapter

        DataList1.DataSource = suppliersAdapter.GetAllSuppliers()
        DataList1.DataBind()

    End Sub

End Class
