Imports NorthwindTableAdapters

Partial Class SuppliersByCountry
    Inherits System.Web.UI.Page

    Protected Sub SearchBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SearchBtn.Click

        Dim suppliersAdapter As New SuppliersTableAdapter

        GridView1.DataSource = suppliersAdapter.GetSuppliersByCountry(CountryTxt.Text)
        GridView1.DataBind()

    End Sub

End Class
