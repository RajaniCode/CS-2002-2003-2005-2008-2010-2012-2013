Imports NorthwindTableAdapters

Partial Class SuppliersTest2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim suppliersAdapter As New SuppliersTableAdapter

        GridView1.DataSource = suppliersAdapter.GetAllSuppliers()
        GridView1.DataBind()

    End Sub

End Class
