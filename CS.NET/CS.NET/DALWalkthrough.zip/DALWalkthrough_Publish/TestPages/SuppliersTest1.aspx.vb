
Partial Class SuppliersTest1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim suppliersAdapter As New NorthwindTableAdapters.SuppliersTableAdapter
        Dim suppliers As Northwind.SuppliersDataTable
        Dim supplier As Northwind.SuppliersRow

        suppliers = suppliersAdapter.GetAllSuppliers()

        For Each supplier In suppliers
            Response.Write("Supplier: " & supplier.CompanyName & "<br>")
        Next

    End Sub


End Class
