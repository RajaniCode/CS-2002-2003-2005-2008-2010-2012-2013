Imports NorthwindTableAdapters

Partial Class SupplierInsertUpdateDelete2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim supplierAdapter As New NorthwindTableAdapters.SuppliersTableAdapter
        Dim suppliers As Northwind.SuppliersDataTable
        Dim supplier As Northwind.SuppliersRow

        ' Obtain all Suppliers in the US
        suppliers = supplierAdapter.GetSuppliersByCountry("USA")

        ' Loop through all suppliers and update any 98042 postcodes to 98004
        For Each supplier In suppliers

            If supplier.PostalCode = "98052" Then
                supplier.PostalCode = "98004"
            End If

        Next

        ' Create a New Supplier Just for Fun
        supplier = suppliers.NewSuppliersRow()

        ' Set new data properties on supplier2 row
        With supplier

            .CompanyName = "Microsoft"
            .ContactName = "ScottGu"
            .Address = "One Microsoft Way"
            .ContactTitle = "General Manager"
            .City = "Redmond"
            .PostalCode = "98052"
            .Country = "USA"
            .Phone = "425-555-1212"

        End With

        ' Add New Supplier to SuppliersDataTable
        suppliers.AddSuppliersRow(supplier)

        ' Update Database with all changes (updates + additions) to SuppliersDataTable
        supplierAdapter.Update(suppliers)

    End Sub

End Class
