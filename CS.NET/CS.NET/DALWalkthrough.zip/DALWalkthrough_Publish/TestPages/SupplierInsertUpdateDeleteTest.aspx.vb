
Partial Class SupplierInsertUpdateDeleteTest
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim supplierAdapter As New NorthwindTableAdapters.SuppliersTableAdapter

        Dim supplierId As Integer

        supplierId = supplierAdapter.InsertSupplier("Microsoft" _
                                                    , "ScottGu" _
                                                    , "General Manager" _
                                                    , "One Microsoft Way" _
                                                    , "Redmond" _
                                                    , "USA" _
                                                    , "98004" _
                                                    , "425-555-1212")

        supplierAdapter.Update("Microsoft" _
                                , "Someone Else" _
                                , "New title" _
                                , "New Address" _
                                , "New City" _
                                , "UK" _
                                , "New Zip" _
                                , "New Number" _
                                , supplierId)

        supplierAdapter.Delete(supplierId)

    End Sub
End Class
