
Partial Class Hierarch2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim suppliersAdapter As New NorthwindTableAdapters.SuppliersTableAdapter
        Dim suppliers As Northwind.SuppliersDataTable
        Dim supplier As Northwind.SuppliersRow

        suppliers = suppliersAdapter.GetAllSuppliers()

        For Each supplier In suppliers

            Response.Write("Supplier: " & supplier.CompanyName & "<br>")

            Dim products As Northwind.ProductsDataTable
            Dim product As Northwind.ProductsRow

            products = supplier.GetProducts()

            For Each product In products
                Response.Write("------- Product: " & product.ProductName & "<br>")
            Next

        Next

    End Sub

End Class
