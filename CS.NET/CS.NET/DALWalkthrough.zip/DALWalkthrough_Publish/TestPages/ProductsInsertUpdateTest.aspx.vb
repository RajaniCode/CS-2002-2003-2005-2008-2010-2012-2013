Partial Class ProductsInsertUpdateTest
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim productsAdapter As New NorthwindTableAdapters.ProductsTableAdapter
        Dim products As Northwind.ProductsDataTable
        Dim product As Northwind.ProductsRow

        ' Obtain all Suppliers in the US
        products = productsAdapter.GetProductsByCategory(1)

        ' Loop through all suppliers and update any 98042 postcodes to 98004
        For Each product In products

            If product.ProductName = "Test" Then
                product.UnitPrice = product.UnitPrice - 0.01
            End If

        Next

        ' Create a New Supplier Just for Fun
        product = products.NewProductsRow()

        ' Set new data properties on supplier2 row
        With product
            .ProductName = "Test"
            .SupplierID = 1
            .UnitsInStock = 34
            .UnitPrice = 34.5
            .CategoryID = 1
            .Discontinued = False
        End With

        ' Add New Supplier to SuppliersDataTable
        products.AddProductsRow(product)

        ' Update Database with all changes (updates + additions) to SuppliersDataTable
        productsAdapter.Update(products)

        GridView1.DataSource = productsAdapter.GetAllProducts()
        GridView1.DataBind()

    End Sub
End Class
