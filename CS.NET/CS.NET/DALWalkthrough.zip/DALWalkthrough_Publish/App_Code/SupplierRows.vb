Imports Microsoft.VisualBasic

Partial Public Class NorthWind

    Partial Public Class SuppliersRow

        Public Function GetProducts() As ProductsDataTable

            Dim productsAdapter As New NorthwindTableAdapters.ProductsTableAdapter
            Return productsAdapter.GetProductsBySupplier(Me.SupplierID)

        End Function

    End Class

End Class
